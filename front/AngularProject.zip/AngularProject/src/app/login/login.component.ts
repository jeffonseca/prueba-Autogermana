import { HttpClient } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
@ViewChild('loginForm', {static: false} ) loginForm: NgForm | null = null;

constructor(private http: HttpClient,private router: Router){}

Login(){

  if(!this.loginForm){
    return;
  }
  console.log('ENTRO')
  const formData ={
    user: this.loginForm.value.username,
    password: this.loginForm.value.password

  }  
  console.log(formData)
  this.http.post<any>('https://localhost:7064/api/AuthControlerr/login',formData)
  .subscribe(
    response =>{
      console.log(response)
      if(response !=undefined){
        localStorage.setItem('token',JSON.stringify(response.isValidateCredencial))
        this.router.navigate(['dashboard']);
      }
    },
    error =>{
      console.log('error al iniciar session')
    }
  );
}

}
