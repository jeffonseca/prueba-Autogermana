import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { error } from 'console';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {

  transacciones: any [] = [];
  token : string | null = null;

  constructor(private http: HttpClient){}

  ngOnInit() : void {
    if(typeof localStorage !== 'undefined'){
      this.token= localStorage.getItem('token');

      if(this.token != null){


      }

    }

  }
  getTransaccion():void{

    if(!this.token){
      return;
    }

    const tokenString = this.token.replace(/^"|"$/g, '');
    const tokenFinsh = tokenString.replace(/\\/g, '');

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${tokenFinsh}`
    });

    this.http.get<any>('https://localhost:7064/api/Transaccion/GetAllTransacciones', { headers })
    .subscribe(
      (data: any []) => {
        this.transacciones = data;
      },
     error => {
      console.error('Error al obtener los datos', error)
     } 
    );
  }
}
